<?php
  $CUR_LVL = 9;
  require_once('include.php');
  $user_agent='BUZZBrowser_V1.9';
  if ($_SERVER['HTTP_USER_AGENT'] == $user_agent){
	  incrementLevel($_SESSION['username'], $CUR_LVL + 1);
	  header("Location: redirect.php"); 
  }
?>	
<html>
<head><title>Felicity Buzz'12/Hackin</title></head>
<body>
<center><img src='firefox_ie7.jpg'>
<h2><font color="Red">Download page</font>
<Center>
<br>
<br>
<?php

if(isset($_POST['code1'])){
	echo "<h1>Invalid key. Please refrain from using pirated keys.</h1>";
}

?>
To Download our Browser (<i>BUZZBrowser2</i>):<br>
<form name="login" method="post" action="download.php">
Enter the serial number: <br>
<input name="code1" maxlength="4" size="4"> - <input name="code2" maxlength="4" size="4"> - <input name="code3" maxlength="4" size="4"><br>
<input type=submit Name="btnSubmit" Value="Download now!" ><br>
<br>
<br>
If you want the serial number for BUZZBrowser2 please dial:<br>
1860-200-1860 (toll free)
<br><br>
If you have <i>BUZZBrowser_V1.9<b></b></i> , you can: <br>
<a href=old_reg.php><img src="upgrade_button.gif" border=0></a>
</body>
</html>
